﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;


namespace CourseWork_EredavkinRA
{
    public class StateStorage
    {
        private List<ArrayDequeState> states = new List<ArrayDequeState>();
        private int currentIndex = -1;

        public void AddState(ArrayDequeState state)
        {
            states.Add(state);
        }

        public void Reset()
        {
            currentIndex = -1;
        }

        public ArrayDequeState GetNextState()
        {
            if (currentIndex < states.Count - 1)
            {
                currentIndex++;
                return states[currentIndex];
            }
            else
            {
                return null;
            }
        }

        //public void SaveToFile(string filePath)
        //{
        //    using (FileStream fileStream = new FileStream(filePath, FileMode.Create))
        //    {
        //        BinaryFormatter binaryFormatter = new BinaryFormatter();
        //        binaryFormatter.Serialize(fileStream, states);
        //    }
        //}

        //public void LoadFromFile(string filePath)
        //{
        //    using (FileStream fileStream = new FileStream(filePath, FileMode.Open))
        //    {
        //        BinaryFormatter binaryFormatter = new BinaryFormatter();
        //        states = (List<ArrayDequeState>)binaryFormatter.Deserialize(fileStream);
        //    }
        //}
    }
}
