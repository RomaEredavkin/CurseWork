﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CourseWork_EredavkinRA
{
    public class ArrayDequeState
    {
        public int[] Elements { get; }
        public int Count { get; }

        public ArrayDequeState(int[] elements, int count)
        {
            Elements = elements;
            Count = count;
        }
    }

}
