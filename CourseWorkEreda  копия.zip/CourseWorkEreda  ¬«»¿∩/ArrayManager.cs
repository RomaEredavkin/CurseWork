﻿using CourseWork_EredavkinRA;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Metadata;
using System.Text;
using System.Threading.Tasks;

namespace CourseWorkEreda
{
    internal class ArrayManager(ArrayDequeParameters parameters)
    {
        public ArrayDeque ArrayDeque = new(parameters);

        public StateStorage Init()
        {
            StateStorage stateStorage = new StateStorage();
            stateStorage.AddState(ArrayDeque.GetState());
            return stateStorage;
        }

        public bool PushBack(int value)
        {
            return ArrayDeque.PushBack(value);
        }

        public bool PushFront(int value)
        {
            return ArrayDeque.PushFront(value);
        }

        public int PopBack()
        {
            return ArrayDeque.PopBack();
        }

        public int PopFront()
        {
            return ArrayDeque.PopFront();
        }
    }
}
