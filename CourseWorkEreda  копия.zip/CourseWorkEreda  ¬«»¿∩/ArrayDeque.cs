﻿using CourseWork_EredavkinRA;

public class ArrayDeque
{
    public int[] array;
    public int Count;
    public int maxCount = 10;
    public bool empty => array.Length == 0;
    public ArrayDeque(ArrayDequeParameters parameters) : this(parameters.InitialElements) { }
    public ArrayDeque() : this(new int[10]){ }
    public ArrayDeque(int[] start_array)
    {
        this.array = start_array;
        maxCount = array.Length;
        Count = 0;
    }
    public bool PushBack(int value) 
    {
        if (InBound(Count))
        {
            array[Count] = value;
            Count++;
            return true;
        }
        return false;
    }
    public int PopBack()
    {
        if (Count > 0)
        {
            return array[--Count];
        }
        return -1;
    }
    public bool PushFront(int value)
    {
        if (InBound(Count))
        {
            Count++;
            for (int i = 0; i < Count; i++)
            {
                array[i + 1] = array[i];
            }
            array[0] = value;
            return true;
        }
        return false;
    }

    public int PopFront()
    {
        if (InBound(Count))
        {
            int res = array[Count - 1];
            for (int i = Count--; i > 0; i--)
            {
                array[i - 1] = array[i];
            }
            return res;
        }
        return -1;
    }
    public ArrayDequeState GetState()
    {
        return new ArrayDequeState(array, Count);
    }
    public bool InBound(int index)
    {
        return index >= 0 && index < maxCount;
    }
}