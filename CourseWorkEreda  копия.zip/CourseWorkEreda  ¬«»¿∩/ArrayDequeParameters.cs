﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CourseWork_EredavkinRA
{
    public class ArrayDequeParameters
    {
        public int[] InitialElements { get; set; }

        public ArrayDequeParameters(int[] initialElements)
        {
            InitialElements = initialElements;
        }
    }

}
